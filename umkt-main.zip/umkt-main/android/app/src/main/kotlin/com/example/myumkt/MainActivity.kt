package com.example.myumkt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
